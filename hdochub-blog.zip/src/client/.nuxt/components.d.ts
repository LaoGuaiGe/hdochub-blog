
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T


export const ArticleCard: typeof import("../components/article/ArticleCard.vue")['default']
export const ArticleToc: typeof import("../components/article/ArticleToc.vue")['default']
export const ArticleLikeButton: typeof import("../components/article/LikeButton.vue")['default']
export const ArticleMarkdownRenderer: typeof import("../components/article/MarkdownRenderer.vue")['default']
export const CommentItem: typeof import("../components/comment/CommentItem.vue")['default']
export const CommentList: typeof import("../components/comment/CommentList.vue")['default']
export const CommonBAlert: typeof import("../components/common/BAlert.vue")['default']
export const CommonBAvatar: typeof import("../components/common/BAvatar.vue")['default']
export const CommonBBadge: typeof import("../components/common/BBadge.vue")['default']
export const CommonBButton: typeof import("../components/common/BButton.vue")['default']
export const CommonBCheckbox: typeof import("../components/common/BCheckbox.vue")['default']
export const CommonBConfirmDialog: typeof import("../components/common/BConfirmDialog.vue")['default']
export const CommonBEmpty: typeof import("../components/common/BEmpty.vue")['default']
export const CommonBInput: typeof import("../components/common/BInput.vue")['default']
export const CommonBLoading: typeof import("../components/common/BLoading.vue")['default']
export const CommonBModal: typeof import("../components/common/BModal.vue")['default']
export const CommonBPagination: typeof import("../components/common/BPagination.vue")['default']
export const CommonBSearchBar: typeof import("../components/common/BSearchBar.vue")['default']
export const CommonBSelect: typeof import("../components/common/BSelect.vue")['default']
export const CommonBSwitch: typeof import("../components/common/BSwitch.vue")['default']
export const CommonBTable: typeof import("../components/common/BTable.vue")['default']
export const CommonBTag: typeof import("../components/common/BTag.vue")['default']
export const CommonBTextarea: typeof import("../components/common/BTextarea.vue")['default']
export const CommonBToastContainer: typeof import("../components/common/BToastContainer.vue")['default']
export const EditorMarkdownEditor: typeof import("../components/editor/MarkdownEditor.vue")['default']
export const LayoutTheFooter: typeof import("../components/layout/TheFooter.vue")['default']
export const LayoutTheHeader: typeof import("../components/layout/TheHeader.vue")['default']
export const LayoutTheSidebar: typeof import("../components/layout/TheSidebar.vue")['default']
export const NuxtWelcome: typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
export const NuxtLayout: typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
export const NuxtErrorBoundary: typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
export const ClientOnly: typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
export const DevOnly: typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
export const ServerPlaceholder: typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const NuxtLink: typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
export const NuxtLoadingIndicator: typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
export const NuxtTime: typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
export const NuxtRouteAnnouncer: typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
export const NuxtImg: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
export const NuxtPicture: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
export const NuxtPage: typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
export const NoScript: typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
export const Link: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
export const Base: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
export const Title: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
export const Meta: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
export const Style: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
export const Head: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
export const Html: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
export const Body: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
export const NuxtIsland: typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
export const LazyArticleCard: LazyComponent<typeof import("../components/article/ArticleCard.vue")['default']>
export const LazyArticleToc: LazyComponent<typeof import("../components/article/ArticleToc.vue")['default']>
export const LazyArticleLikeButton: LazyComponent<typeof import("../components/article/LikeButton.vue")['default']>
export const LazyArticleMarkdownRenderer: LazyComponent<typeof import("../components/article/MarkdownRenderer.vue")['default']>
export const LazyCommentItem: LazyComponent<typeof import("../components/comment/CommentItem.vue")['default']>
export const LazyCommentList: LazyComponent<typeof import("../components/comment/CommentList.vue")['default']>
export const LazyCommonBAlert: LazyComponent<typeof import("../components/common/BAlert.vue")['default']>
export const LazyCommonBAvatar: LazyComponent<typeof import("../components/common/BAvatar.vue")['default']>
export const LazyCommonBBadge: LazyComponent<typeof import("../components/common/BBadge.vue")['default']>
export const LazyCommonBButton: LazyComponent<typeof import("../components/common/BButton.vue")['default']>
export const LazyCommonBCheckbox: LazyComponent<typeof import("../components/common/BCheckbox.vue")['default']>
export const LazyCommonBConfirmDialog: LazyComponent<typeof import("../components/common/BConfirmDialog.vue")['default']>
export const LazyCommonBEmpty: LazyComponent<typeof import("../components/common/BEmpty.vue")['default']>
export const LazyCommonBInput: LazyComponent<typeof import("../components/common/BInput.vue")['default']>
export const LazyCommonBLoading: LazyComponent<typeof import("../components/common/BLoading.vue")['default']>
export const LazyCommonBModal: LazyComponent<typeof import("../components/common/BModal.vue")['default']>
export const LazyCommonBPagination: LazyComponent<typeof import("../components/common/BPagination.vue")['default']>
export const LazyCommonBSearchBar: LazyComponent<typeof import("../components/common/BSearchBar.vue")['default']>
export const LazyCommonBSelect: LazyComponent<typeof import("../components/common/BSelect.vue")['default']>
export const LazyCommonBSwitch: LazyComponent<typeof import("../components/common/BSwitch.vue")['default']>
export const LazyCommonBTable: LazyComponent<typeof import("../components/common/BTable.vue")['default']>
export const LazyCommonBTag: LazyComponent<typeof import("../components/common/BTag.vue")['default']>
export const LazyCommonBTextarea: LazyComponent<typeof import("../components/common/BTextarea.vue")['default']>
export const LazyCommonBToastContainer: LazyComponent<typeof import("../components/common/BToastContainer.vue")['default']>
export const LazyEditorMarkdownEditor: LazyComponent<typeof import("../components/editor/MarkdownEditor.vue")['default']>
export const LazyLayoutTheFooter: LazyComponent<typeof import("../components/layout/TheFooter.vue")['default']>
export const LazyLayoutTheHeader: LazyComponent<typeof import("../components/layout/TheHeader.vue")['default']>
export const LazyLayoutTheSidebar: LazyComponent<typeof import("../components/layout/TheSidebar.vue")['default']>
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
export const LazyLink: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
export const LazyBase: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
export const LazyTitle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
export const LazyMeta: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
export const LazyStyle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
export const LazyHead: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
export const LazyHtml: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
export const LazyBody: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>

export const componentNames: string[]
