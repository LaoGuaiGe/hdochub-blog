
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T

interface _GlobalComponents {
  ArticleCard: typeof import("../../components/article/ArticleCard.vue")['default']
  ArticleToc: typeof import("../../components/article/ArticleToc.vue")['default']
  ArticleLikeButton: typeof import("../../components/article/LikeButton.vue")['default']
  ArticleMarkdownRenderer: typeof import("../../components/article/MarkdownRenderer.vue")['default']
  CommentItem: typeof import("../../components/comment/CommentItem.vue")['default']
  CommentList: typeof import("../../components/comment/CommentList.vue")['default']
  CommonBAlert: typeof import("../../components/common/BAlert.vue")['default']
  CommonBAvatar: typeof import("../../components/common/BAvatar.vue")['default']
  CommonBBadge: typeof import("../../components/common/BBadge.vue")['default']
  CommonBButton: typeof import("../../components/common/BButton.vue")['default']
  CommonBCheckbox: typeof import("../../components/common/BCheckbox.vue")['default']
  CommonBConfirmDialog: typeof import("../../components/common/BConfirmDialog.vue")['default']
  CommonBEmpty: typeof import("../../components/common/BEmpty.vue")['default']
  CommonBInput: typeof import("../../components/common/BInput.vue")['default']
  CommonBLoading: typeof import("../../components/common/BLoading.vue")['default']
  CommonBModal: typeof import("../../components/common/BModal.vue")['default']
  CommonBPagination: typeof import("../../components/common/BPagination.vue")['default']
  CommonBSearchBar: typeof import("../../components/common/BSearchBar.vue")['default']
  CommonBSelect: typeof import("../../components/common/BSelect.vue")['default']
  CommonBSwitch: typeof import("../../components/common/BSwitch.vue")['default']
  CommonBTable: typeof import("../../components/common/BTable.vue")['default']
  CommonBTag: typeof import("../../components/common/BTag.vue")['default']
  CommonBTextarea: typeof import("../../components/common/BTextarea.vue")['default']
  CommonBToastContainer: typeof import("../../components/common/BToastContainer.vue")['default']
  EditorMarkdownEditor: typeof import("../../components/editor/MarkdownEditor.vue")['default']
  LayoutTheFooter: typeof import("../../components/layout/TheFooter.vue")['default']
  LayoutTheHeader: typeof import("../../components/layout/TheHeader.vue")['default']
  LayoutTheSidebar: typeof import("../../components/layout/TheSidebar.vue")['default']
  NuxtWelcome: typeof import("../../node_modules/nuxt/dist/app/components/welcome.vue")['default']
  NuxtLayout: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
  NuxtErrorBoundary: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
  ClientOnly: typeof import("../../node_modules/nuxt/dist/app/components/client-only")['default']
  DevOnly: typeof import("../../node_modules/nuxt/dist/app/components/dev-only")['default']
  ServerPlaceholder: typeof import("../../node_modules/nuxt/dist/app/components/server-placeholder")['default']
  NuxtLink: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-link")['default']
  NuxtLoadingIndicator: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
  NuxtTime: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
  NuxtRouteAnnouncer: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
  NuxtImg: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
  NuxtPicture: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
  NuxtPage: typeof import("../../node_modules/nuxt/dist/pages/runtime/page")['default']
  NoScript: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['NoScript']
  Link: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Link']
  Base: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Base']
  Title: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Title']
  Meta: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Meta']
  Style: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Style']
  Head: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Head']
  Html: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Html']
  Body: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Body']
  NuxtIsland: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-island")['default']
  LazyArticleCard: LazyComponent<typeof import("../../components/article/ArticleCard.vue")['default']>
  LazyArticleToc: LazyComponent<typeof import("../../components/article/ArticleToc.vue")['default']>
  LazyArticleLikeButton: LazyComponent<typeof import("../../components/article/LikeButton.vue")['default']>
  LazyArticleMarkdownRenderer: LazyComponent<typeof import("../../components/article/MarkdownRenderer.vue")['default']>
  LazyCommentItem: LazyComponent<typeof import("../../components/comment/CommentItem.vue")['default']>
  LazyCommentList: LazyComponent<typeof import("../../components/comment/CommentList.vue")['default']>
  LazyCommonBAlert: LazyComponent<typeof import("../../components/common/BAlert.vue")['default']>
  LazyCommonBAvatar: LazyComponent<typeof import("../../components/common/BAvatar.vue")['default']>
  LazyCommonBBadge: LazyComponent<typeof import("../../components/common/BBadge.vue")['default']>
  LazyCommonBButton: LazyComponent<typeof import("../../components/common/BButton.vue")['default']>
  LazyCommonBCheckbox: LazyComponent<typeof import("../../components/common/BCheckbox.vue")['default']>
  LazyCommonBConfirmDialog: LazyComponent<typeof import("../../components/common/BConfirmDialog.vue")['default']>
  LazyCommonBEmpty: LazyComponent<typeof import("../../components/common/BEmpty.vue")['default']>
  LazyCommonBInput: LazyComponent<typeof import("../../components/common/BInput.vue")['default']>
  LazyCommonBLoading: LazyComponent<typeof import("../../components/common/BLoading.vue")['default']>
  LazyCommonBModal: LazyComponent<typeof import("../../components/common/BModal.vue")['default']>
  LazyCommonBPagination: LazyComponent<typeof import("../../components/common/BPagination.vue")['default']>
  LazyCommonBSearchBar: LazyComponent<typeof import("../../components/common/BSearchBar.vue")['default']>
  LazyCommonBSelect: LazyComponent<typeof import("../../components/common/BSelect.vue")['default']>
  LazyCommonBSwitch: LazyComponent<typeof import("../../components/common/BSwitch.vue")['default']>
  LazyCommonBTable: LazyComponent<typeof import("../../components/common/BTable.vue")['default']>
  LazyCommonBTag: LazyComponent<typeof import("../../components/common/BTag.vue")['default']>
  LazyCommonBTextarea: LazyComponent<typeof import("../../components/common/BTextarea.vue")['default']>
  LazyCommonBToastContainer: LazyComponent<typeof import("../../components/common/BToastContainer.vue")['default']>
  LazyEditorMarkdownEditor: LazyComponent<typeof import("../../components/editor/MarkdownEditor.vue")['default']>
  LazyLayoutTheFooter: LazyComponent<typeof import("../../components/layout/TheFooter.vue")['default']>
  LazyLayoutTheHeader: LazyComponent<typeof import("../../components/layout/TheHeader.vue")['default']>
  LazyLayoutTheSidebar: LazyComponent<typeof import("../../components/layout/TheSidebar.vue")['default']>
  LazyNuxtWelcome: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
  LazyNuxtLayout: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
  LazyNuxtErrorBoundary: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
  LazyClientOnly: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/client-only")['default']>
  LazyDevOnly: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/dev-only")['default']>
  LazyServerPlaceholder: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
  LazyNuxtLink: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
  LazyNuxtLoadingIndicator: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
  LazyNuxtTime: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
  LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
  LazyNuxtImg: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
  LazyNuxtPicture: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
  LazyNuxtPage: LazyComponent<typeof import("../../node_modules/nuxt/dist/pages/runtime/page")['default']>
  LazyNoScript: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
  LazyLink: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Link']>
  LazyBase: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Base']>
  LazyTitle: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Title']>
  LazyMeta: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Meta']>
  LazyStyle: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Style']>
  LazyHead: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Head']>
  LazyHtml: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Html']>
  LazyBody: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Body']>
  LazyNuxtIsland: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-island")['default']>
}

declare module 'vue' {
  export interface GlobalComponents extends _GlobalComponents { }
}

export {}
