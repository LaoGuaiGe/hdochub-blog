import{r as e}from"./iP3KPjp9.js";import{u as s}from"./BwukwS25.js";import{d as a,o as c,c as n,a as o,u as r,b as d}from"./BstmquYs.js";import"./C1qNvj-K.js";const i={class:"container-list py-6"},u={class:"mx-auto max-w-content"},m={class:"border-2 border-black bg-white p-6 md:p-8"},l=["innerHTML"],h=`# 关于本站

hdochub 个人技术博客，记录工程生涯中的技术问题、解决方案与观点。

## 联系方式

- 邮箱：blog@hdochub.com
- GitHub：github.com/hdochub`,g=a({__name:"about",setup(_){const t=d(()=>e(h).html);return s({title:"关于 - hdochub"}),(b,p)=>(c(),n("div",i,[o("div",u,[o("div",m,[o("article",{class:"prose-brutal",innerHTML:r(t)},null,8,l)])])]))}});export{g as default};
