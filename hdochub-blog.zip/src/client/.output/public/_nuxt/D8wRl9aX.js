import{aa as t,T as o,z as a}from"./BstmquYs.js";const u=t(e=>{if(!o().isLoggedIn)return a(`/login?redirect=${encodeURIComponent(e.fullPath)}`)});export{u as default};
